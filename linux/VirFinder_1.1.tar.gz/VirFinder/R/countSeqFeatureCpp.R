countSeqFeatureCpp <-
function(RseqDNA, k) {
    Sys.setenv("PKG_CXXFLAGS"="-std=c++11")
    .Call('VirFinder_countSeqFeatureCpp', PACKAGE = 'VirFinder', RseqDNA, k)
}
